**Tugas**
------
1. Buatlah suatu REST API sederhana dan tampilkan dalam bentuk halaman web.
2. Sertakan hasil screenshoot tugas dan hasil ekspor database di dalam folder sourcecode.
3. Uploadlah hasil tugas ke sebuah repository yang diberi nama ___LabPI_createAPI___ di akun Github masing-masing.
4. Kirim link repository-nya ke 1998code@gmail.com dengan subjek LabPI1_NIM.
5. Deadline: Selasa, 22 Mei 2019 pukul 23:00 WIB.
